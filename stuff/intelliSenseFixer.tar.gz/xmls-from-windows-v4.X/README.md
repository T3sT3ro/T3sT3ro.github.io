# What is this?

This is a collection of xml definition files collected from windows 10's 
`%PROGRAMFILESDIR%Reference Assemblies\Microsoft\Framework.NETFramework\v4.7.2` directory

I don't know how those files relate to those in the unity editor, but they are mostly matching, and intellisense works in general.

Chug them into Unity editor's `2022.1.22f1/Editor/Data/UnityReferenceAssemblies/unity-4.8-api/` directory (change version appropriately) and restart reider/VS Code/VS. Now your decompiled sources should point in the right direction

