# Unity IntelliSense fixer by Tooster

- a collection of xml definition files collected from windows 10's `%PROGRAMFILESDIR%Reference Assemblies\Microsoft\Framework.NETFramework\v4.7.2` directory and for .NET Framework API compatibility level
- a `netstandard.xml` for dotnet 2.1.0 and for .NET Standard API compatibility level
- a script that links those files to appropriate folders in unity editor directory


I don't know how those xml files relate to those in the unity editor (i.e. if all symbols in dll correspond 1:1 to xmls), but they are mostly matching, and intellisense works in general.

## Usage

1. extract this tar into the location of your unity editor instances, for example on my machine:
2. 
    ```
    ~/Unity/Editor:
    └ 2022.1.2f1/
    └ 2022.1.3f1/
    └ 2022.1.22f1/
    └ installDotnetDocs.sh
    └ netstandard.xml
    └ xmls-from-windows-v4.X
    ```

3. Run `./installDotnetDocs.sh <--framework | --standard | --diff > <unity editor version>`
4. Running without arguments prints help
5. Restart your IDE
6. Now you should have symbols

This simple scripts creates symbolic links to corresponding `.xml` files in proper editor directories, for example:

- for `--framework`: `2022.1.22f1/Editor/Data/UnityReferenceAssemblies/unity-4.8-api/`
- for `--standard`: `2022.1.22f1/Editor/Data/NetStandard/ref/2.1.0/`