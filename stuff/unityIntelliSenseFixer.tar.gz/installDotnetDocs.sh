#!/bin/bash

NETFRAMEWORK_48_PATH="$2/Editor/Data/UnityReferenceAssemblies/unity-4.8-api/"
NETFRAMEWORK_ENGINE_PATH="$2/Editor/Data/UnityReferenceAssemblies/unity-engine-api/"
#XML_PATH="/usr/lib/dotnet/packs/NETStandard.Library.Ref/2.1.0/ref/netstandard2.1/netstandard.xml"
NESTANDARD_PATH="$2/Editor/Data/NetStandard/ref/2.1.0/netstandard.xml"

cd $(dirname $0)

generate_diff() {
    if [[ $# -ne 1 ]]; then 
        print_help; exit 1; 
    fi;

    find $NETFRAMEWORK_48_PATH     -name '*.dll' | sed "s#$NETFRAMEWORK_48_PATH##;     s/\.dll\$//" | sort > dlls-48.txt # generates sorted list of dll names (with subdirs) without extensions
    find $NETFRAMEWORK_ENGINE_PATH -name '*.dll' | sed "s#$NETFRAMEWORK_ENGINE_PATH##; s/\.dll\$//" | sort > dlls-engine.txt # generates sorted list of dll names (with subdirs) without extensions
    find xmls-from-windows-v4.X/ -name '*.xml' | cut -d'/' -f2 | sed 's/\.xml$//' | sort > provided-xmls.txt # generates sorted list of xml names without extensions
    
    echo "Generated dlls-48.txt, dlls-engine.txt, xmls.txt"
    echo -e "Compare using for example:\n diff -i --color=always -y dlls-48.txt provided-xmls.txt"

    echo "diff of dlls in eunity-4.8-api (left) and provided xmls (right)"
    diff -i --color=always -y dlls-48.txt provided-xmls.txt
}

print_help() {
    echo "Usages:"
    echo "  ./installDotnetDocs.sh --diff <editor_path>           generates lists of dlls (from unity) and xmls (downloaded)";
    echo "  ./installDotnetDocs.sh --framework <editor_path>      creates symlinks to xmls for the .net framework API compatibility level";
    echo "  ./installDotnetDocs.sh --standard <editor_path>       creates symlink to netstandard.xml in .net standard API compatibility level";
    exit 1;
}

link_framework() {
    if [[ $# -ne 1 ]]; then 
        print_help; exit 1; 
    fi;


    case ${yn:-y} in
        [yY] )
            echo "linking all framework xmls...";
            find xmls-from-windows-v4.X/ -name '*.xml' -printf "%f\0" | xargs -0 -I{} ln -sf ${PWD}/xmls-from-windows-v4.X/{} $NETFRAMEWORK_48_PATH/{}
            exit 0;;
        * ) 
            echo "aborted...";
            exit 1;;
    esac
}

link_standard() {
    if [[ $# -ne 1 ]]; then 
        print_help; exit 1; 
    fi;

#    echo "Locating netstandard 2.1.0 on system..."
#    XML_PATH="$(locate netstandard2.1/netstandard.xml)"
    XML_PATH="netstandard.xml"

    if [[ -z "$XML_PATH" ]]; then
        echo "couldn't find the xml file"
        exit 1;
    fi

    echo "Located netstandard.xml for 2.1.0 at: $(realpath $XML_PATH)"

    read -p "Install to $NESTANDARD_PATH? (Y/n)" yn
    case ${yn:-y} in
        [yY] )
            echo "updating symlink...";
            ln -sf "$XML_PATH" "$NESTANDARD_PATH";;
        * ) 
            echo "aborted...";
            exit 1;;
    esac
}

case $1 in
    -d|--diff)
        generate_diff $2;;
    -s|--standard)
        link_standard $2;;
    -f|--framework)
        link_framework $2;;
    *)
        print_help;;
esac

